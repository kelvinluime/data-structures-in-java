/**
 * Student Name: Kin Man Lui (Kelvin)
 * Instructor: Professor Schatz
 * Course: CS111C-001
 * Assignment:
 * Date:
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
public class Tester{
    public static void main(String[] args){

        //Compare array list and binary search tree's search times
        BinarySearchTree<Integer> bst = new BinarySearchTree<>();
        ArrayList<Integer> al = new ArrayList<>(100000);
        DictionaryInterface<String, Integer> dictionary = new Dictionary<>();

        for(int i = 0; i < 100000; i++){
            bst.add((int)(Math.random() * 999999) + 1);
        }

        while(al.size() < 100000){
            al.add((int)(Math.random() * 999999) + 1);
        }

        Date start = new Date();
        for(int i = 0; i < 1000; i++){
            bst.getEntry(i);
        }
        Date end = new Date();
        System.out.println("Search time for binary search tree: " + (end.getTime() - start.getTime()) + "ms");

        start = new Date();
        for(int i = 0; i < 1000; i++){
            al.indexOf(i);
        }
        end = new Date();
        System.out.println("Search time for array list: " + (end.getTime() - start.getTime()) + "ms");

        //Add entries into dictionary
        System.out.println("Testing Dictionary.....");
        dictionary.add("a", 1);
        dictionary.add("b", 2);
        dictionary.add("c", 3);
        dictionary.add("d", 4);
        dictionary.add("e", 5);
        dictionary.add("f", 6);

        //Display entries in dictionary with iterators
        Iterator<String> keyIterator = dictionary.getKeyIterator();
        Iterator<Integer> valueIterator = dictionary.getValueIterator();
        while(keyIterator.hasNext()) {
            System.out.println(keyIterator.next() + " " + valueIterator.next());
        }
    }
}

/**
 * Student Name: Kin Man Lui (Kelvin)
 * Instructor: Professor Schatz
 * Course: CS111C-001
 * Assignment:
 * Date:
 */
public class EmptyTreeException extends RuntimeException {

    public EmptyTreeException(){
        super();
    }

    public EmptyTreeException(String message){
        super(message);
    }

}

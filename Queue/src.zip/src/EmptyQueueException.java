/**
 * Student Name: Kin Man Lui (Kelvin)
 * Instructor: Professor Schatz
 * Course: CS111C-001
 * Assignment: Two Queues
 * Date: 10/5/2016
 */
public class EmptyQueueException extends RuntimeException {

        public EmptyQueueException(String message){
            super(message);
        }

        public EmptyQueueException(){super();}

}

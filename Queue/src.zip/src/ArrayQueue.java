/**
 * Student Name: Kin Man Lui (Kelvin)
 * Instructor: Professor Schatz
 * Course: CS111C-001
 * Assignment: Two Queues
 * Date: 10/5/2016
 */
public class ArrayQueue<T> implements QueueInterface<T> {

    private T[] q;
    private int frontIndex;
    private int backIndex;
    private static final int DEFAULT_INITIAL_CAPACITY = 50;
    private static final int MAX_CAPACITY = 10000;

    public ArrayQueue(){
        this(DEFAULT_INITIAL_CAPACITY);
    }

    public ArrayQueue(int capacity){
        @SuppressWarnings("unchecked")
        T[] temp = (T[])new Object[capacity + 1];
        q = temp;
        frontIndex = 0;
        backIndex = capacity;
    }

    public void enqueue(T entry) {
        ensureCapacity();
        backIndex = (backIndex + 1) % q.length;
        q[backIndex] = entry;

    }

    public T dequeue() throws EmptyQueueException{
        if(isEmpty())
            throw new EmptyQueueException();
        else{
            T front = getFront();
            q[frontIndex] = null;
            frontIndex = (frontIndex + 1) % q.length;
            return front;
        }
    }

    public T getFront() throws EmptyQueueException{
        T front = null;
        try{
            front = q[frontIndex];
        }
        catch(EmptyQueueException e){
            e.printStackTrace();
        }
        return front;
    }

    public void splice(QueueInterface<T> anotherQ) throws EmptyQueueException{
        if(anotherQ.isEmpty())
            throw new EmptyQueueException();
        while (!anotherQ.isEmpty())
            this.enqueue(anotherQ.dequeue());
    }

    public void splice2(ArrayQueue<T> anotherQ) throws EmptyQueueException{
        if(anotherQ.isEmpty())
            throw new EmptyQueueException();
        int numberOfEntries = 0;
        if(anotherQ.backIndex > anotherQ.frontIndex){
            numberOfEntries = backIndex - frontIndex + 1;
        }
        else if(anotherQ.backIndex < anotherQ.frontIndex) {
            numberOfEntries = anotherQ.q.length - frontIndex + anotherQ.backIndex + 1;
        }
        for(int i = 0; i < numberOfEntries; i++){
            this.ensureCapacity();
            this.backIndex = (this.backIndex + 1) % this.q.length;
            this.q[backIndex] = anotherQ.q[(anotherQ.frontIndex + i) % anotherQ.q.length];
        }
    }

    public boolean isEmpty() {
        return (backIndex + 1) %  q.length == frontIndex;
    }

    public boolean isFull() {
        return frontIndex == (backIndex + 2) % q.length;
    }

    public void clear() {
        while(!isEmpty())
            dequeue();
    }

    private void ensureCapacity(){
        if(isFull() && q.length * 2 <= MAX_CAPACITY){
            T[] oldQueue = q;
            int oldSize = oldQueue.length;
            @SuppressWarnings("unchecked")
            T[] temp = (T[])new Object[oldSize * 2];
            q = temp;
            for(int i = 0; i < oldSize - 1; i++){
                q[i] = oldQueue[frontIndex];
                frontIndex = (frontIndex + 2) % oldSize;
            }
            frontIndex = 0;
            backIndex = oldSize - 2;
        }
    }
}
